package org.example;

public class HeightException extends SizeException{
    public HeightException(String message) {
        super(message);
    }
}

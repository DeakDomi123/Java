/**
 * This package contains examples of exception handling
 */
package org.example;
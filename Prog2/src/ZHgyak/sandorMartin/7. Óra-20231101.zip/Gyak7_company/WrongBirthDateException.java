package org.example;

public class WrongBirthDateException extends CompanyException{
    public WrongBirthDateException(String message) {
        super(message);
    }
}

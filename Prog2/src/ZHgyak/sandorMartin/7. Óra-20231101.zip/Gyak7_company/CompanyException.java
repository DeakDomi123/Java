package org.example;

public class CompanyException extends Exception{
    public CompanyException(String message) {
        super(message);
    }
}

package org.example;

public class ShoeSizeException extends SizeException{
    public ShoeSizeException(String message) {
        super(message);
    }
}

package org.example;

import java.util.Objects;

public class KTort {
    private int szamlalo, nevezo;

    public final double pi=3.14;
    public static int tortOsztalyDarabszam=0;

    public double ertek(){
        return (double)szamlalo/nevezo;
    }

    public KTort(int szamlalo, int nevezo)
    {
        this(szamlalo);
        this.nevezo=nevezo;
    }

    public KTort(int szamlalo){
        this();
        this.szamlalo=szamlalo;
    }
    public KTort(){
        szamlalo=0;
        nevezo=1;
        tortOsztalyDarabszam++;
    }

    public int getSzamlalo(){
        return szamlalo;
    }
    public int getNevezo(){
        return nevezo;
    }

    public void setSzamlalo(int szamlalo){
        this.szamlalo=szamlalo;
    }
    public void setNevezo(int nevezo){
        this.nevezo=nevezo;
    }

    public void egyszerusit(){
        if (nevezo<0){
            szamlalo=-szamlalo;
            nevezo=-nevezo;
        }

        int p=Math.max(Math.abs(szamlalo),Math.abs(nevezo));
        int q=Math.min(Math.abs(szamlalo),Math.abs(nevezo));
        int lnko;
        while(true){
            if (p==q){
                lnko=p;
                break;
            }
            if (p-q >0){
                p=p-q;
            }
            else{
                int dummy=p;
                p=q;
                q=dummy;

            }
        }
        szamlalo /= lnko;
        nevezo /= lnko;
    }

    @Override
    public String toString(){
        StringBuilder builder=new StringBuilder();

        builder.append("[Számláló: ");
        builder.append(szamlalo);
        builder.append(", Nevező: ");
        builder.append(nevezo);
        builder.append(", Érték: ");
        builder.append(ertek());
        builder.append("]");

        return builder.toString();

    }

    @Override
    public int hashCode(){
        return Objects.hash(szamlalo,nevezo);
    }

    @Override
    public boolean equals(Object obj){
        if (this == obj)
            return true;
        if (!(obj instanceof KTort))
            return false;
        KTort other = (KTort) obj;
        return nevezo == other.nevezo && szamlalo == other.szamlalo;
    }


}

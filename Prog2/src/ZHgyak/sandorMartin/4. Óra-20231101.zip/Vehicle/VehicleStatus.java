public enum VehicleStatus {
    MOVE,
    STOP,
    PARK
}

package org.example;

import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        double[] szamTomb=new double[5];
        Scanner sc=new Scanner(System.in);
        System.out.println("Adj meg 5 törtet:");
        for (int i=0; i<5; i++){
            szamTomb[i]=sc.nextDouble();
        }
        double osszeg=0;
        double min=Double.MAX_VALUE;
        double max=Double.MIN_VALUE;
        System.out.println("A tomb elemei a kovetkezok:");
        java.util.Arrays.sort(szamTomb);
        for (double d: szamTomb){
            System.out.print(d+" ");
            osszeg=d;
            if (d > max)
                max=d;
            else if (d < min)
                min=d;
        }

        System.out.println("A tömb elemeinek az összege: "+osszeg);
        System.out.println("Átlaga: "+osszeg/szamTomb.length);
        System.out.println("Min: "+min +"\t max: " +max);
        System.out.println("A tömb elemei egybe kiíratva:" +java.util.Arrays.toString(szamTomb));



    }
}
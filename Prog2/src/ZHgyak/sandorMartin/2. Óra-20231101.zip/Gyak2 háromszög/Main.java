package org.example;

// Ha bármely két oldal összege nagyobb mint a 3. oldal,
//akkor a háromszög létezik.

import java.util.Scanner;

//Ha a^2 + b^2  < c^2    --> hegyesszögű
//              =        --> derékszögű
//              >        --> tompaszögű
public class Main {
    public static void main(String[] args) {
        double[] oldalak=new double[3];
        Scanner sc=new Scanner(System.in);
        System.out.println("Adj meg három törtet ;-vel elválasztva");
        String input=sc.nextLine();
        String[] szetvalasztott_input=input.split(";");
        for (int i=0; i<3; i++){
            oldalak[i]=Double.parseDouble(szetvalasztott_input[i]);
        }
        java.util.Arrays.sort(oldalak);

        if (oldalak[0]+oldalak[1] > oldalak[2] &&
            oldalak[1]+oldalak[2] > oldalak[0] &&
            oldalak[2]+oldalak[0] > oldalak[1]){
            System.out.println("A háromszög létezik!");

            if ((oldalak[0]*oldalak[0] + oldalak[1]*oldalak[1]) < oldalak[2]*oldalak[2]){
                System.out.println("A háromszög hegyesszögű");
            }
            else if ((oldalak[0]*oldalak[0] + oldalak[1]*oldalak[1]) == oldalak[2]*oldalak[2]){
                System.out.println("A háromszög derékszögű");
            }
            else {
                System.out.println("A háromszög tompaszögű");
            }
        }

    }
}
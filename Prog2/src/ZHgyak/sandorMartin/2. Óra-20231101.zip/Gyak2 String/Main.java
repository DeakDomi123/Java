package org.example;

import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
         String[] tomb=new String[5];
         Scanner sc=new Scanner(System.in);
         System.out.println("Adj meg öt szót ;-vel elválasztva!");
         String input=sc.nextLine();
         tomb=input.split(";");
         System.out.println(java.util.Arrays.toString(tomb));

         for(String str : tomb){
             str=str.replace(" ","");
             System.out.println("A " +str +" string hossza: " +str.length());
             System.out.println("A " +str +" string csupa nagybetűvel: " +str.toUpperCase());
             System.out.println("A " +str +" string csupa kisbetűvel: " +str.toLowerCase());
             str.isBlank();
             if (str.toLowerCase().contains("ma")){
                 System.out.println("A " +str+" string tartalmazza az 'ma' karakterláncot");
             }
             System.out.println("-----------------------------------------");
         }

        }
    }

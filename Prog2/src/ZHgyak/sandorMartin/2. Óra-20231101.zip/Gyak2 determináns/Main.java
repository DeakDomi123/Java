package org.example;

import java.util.Scanner;

/*
    1 2 3
    4 5 6
    7 8 9

    A főátlók menti elemek szorzatainak az összege mínusz a mellékátlók szorzatainak az összege

    főátlók összege: 1*5*9 + 2*6*7 + 3*4*8
    mellékátlók összege: 3*5*7 + 2*4*9 + 1*6*8
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double[][] m = new double[3][3];

        System.out.println("Kérem egy 3*3-as mátrix elemeit");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.println("["+(i+1)+","+(j+1)+"]:");
                m[i][j] = sc.nextDouble();
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++)
                System.out.print(m[i][j]+"; ");
            System.out.println();
        }
        double foatlo_szorzatosszeg=m[0][0]*m[1][1]*m[2][2]+m[1][0]*m[2][1]*m[0][2]+m[2][0]*m[0][1]*m[1][2];
        double mellekatlo_szorzatosszeg=m[2][0]*m[1][1]*m[0][2]+m[1][0]*m[0][1]*m[2][2]+m[0][0]*m[2][1]*m[1][2];
        double d=foatlo_szorzatosszeg-mellekatlo_szorzatosszeg;
        System.out.println("determinansa: "+d);
        sc.close();
    }
}
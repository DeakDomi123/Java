package org.example;

public interface MeansOfTransport extends Move{
    double getCarryingCapacityInKg();
    double getWeightInKg();
}

package org.example;

public interface Move {
    double getSpeedInMeterPerSec();
}

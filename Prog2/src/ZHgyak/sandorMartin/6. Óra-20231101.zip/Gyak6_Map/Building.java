package org.example;

import java.util.Objects;

public class Building implements Comparable<Building>{
    private String name;
    private String address;
    public Building(String name, String address) {
        super();
        this.name = name;
        this.address = address;
    }
    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Building [name=");
        builder.append(name);
        builder.append(", address=");
        builder.append(address);
        builder.append("]");
        return builder.toString();
    }
    @Override
    public int hashCode() {
        return Objects.hash(name.toLowerCase());
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!(obj instanceof Building))
            return false;
        Building other = (Building) obj;
        return Objects.equals(name.toLowerCase(), other.name.toLowerCase());
    }
    @Override
    public int compareTo(Building o) {
        return this.name.toLowerCase().compareTo(o.name.toLowerCase());
    }



}

package org.example.PackageAbstractAnimals;

public interface Animal {
    String makeSound();
}

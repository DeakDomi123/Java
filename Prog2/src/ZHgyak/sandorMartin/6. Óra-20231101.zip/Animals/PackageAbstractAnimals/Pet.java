package org.example.PackageAbstractAnimals;

public interface Pet extends Animal {
    String getName();
}

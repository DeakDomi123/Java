package org.example.PackageAbstractAnimals;

public interface ProtectedAnimal {
    String getLawNumber();
}

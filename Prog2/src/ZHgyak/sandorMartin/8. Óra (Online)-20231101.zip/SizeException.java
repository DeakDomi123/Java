package j08Expection01Emp;

public class SizeException extends CompanyException {

	public SizeException(String message) {
		super(message);
	}

}

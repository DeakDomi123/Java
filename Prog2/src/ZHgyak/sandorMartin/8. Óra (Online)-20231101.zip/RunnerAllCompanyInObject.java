package j08Expection01Emp;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import java.util.ArrayList;

public class RunnerAllCompanyInObject {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		ArrayList<Company> companyList = new ArrayList<>();

		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("CompanyAllObj.bin"))) {
			while (true) {
				Company c = (Company) ois.readObject();
				// System.out.println(c);
				companyList.add(c);
			}
		} catch (EOFException e) {
			System.out.println("befejezte");
		}

		for (Company company : companyList) {
			System.out.println(company);
		}

	}
}

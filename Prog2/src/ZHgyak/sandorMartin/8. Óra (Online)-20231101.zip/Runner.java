package j08Expection01Emp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;

public class Runner {

	public static void main(String[] args) {
		ArrayList<Company> comanyList = new ArrayList<>();
		comanyList.add(new Company("deik", "HA"));
		comanyList.add(new Company("BTK", "JS"));
		comanyList.add(new Company("TTK", "PA"));
		comanyList.add(new Company("NI IT", "SC"));
		comanyList.add(new Company("EPAM IT", "IGYB"));

		try (Formatter fm = new Formatter(new File("company.txt"))) {
			for (Company company : comanyList) {
				fm.format("%s; %s\n", company.getName(), company.getNameOfLeader());
			}

		} catch (FileNotFoundException e) {
			System.out.println("nincs ilyen file");
		}
	}
}

package j08Expection01Emp;

import java.io.File;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Formatter;

public class RunnerPersonOut {

	public static void main(String[] args) throws WrongBirthDateExcception, SizeException {
		ArrayList<Person> personList = new ArrayList<>();

		personList.add(new Person("Anna", LocalDate.of(2020, 1, 1)));
		personList.add(new Person("Bela", LocalDate.of(2019, 5, 1), "Beluska"));
		personList.add(new Employee(30, "Cili", LocalDate.of(2018, 3, 3), "Cilike"));
		personList.add(new Employee(40, "Dini", LocalDate.of(2017, 4, 4)));
		Employee e = new Employee(50, "Elemer", LocalDate.of(2020, 5, 5));
		personList.add(e);
		EmployeeWithSizes ew = new EmployeeWithSizes(60, "Ferenc", LocalDate.of(2020, 6, 6));
		ew.setHeightInCm(200);
		ew.setShoeSize(40);
		personList.add(ew);

		try (Formatter formatter = new Formatter(new File("person.txt"))) {
			for (Person person : personList) {
				System.out.println(person);
				formatter.format("%s\n", person);
			}

		} catch (FileNotFoundException e1) {
			System.out.println("nincs fájl");
		}

	}
}

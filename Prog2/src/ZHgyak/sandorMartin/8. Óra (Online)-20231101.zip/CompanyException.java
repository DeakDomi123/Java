package j08Expection01Emp;

public class CompanyException extends Exception {

	public CompanyException(String message) {
		super(message);
	}
	
	
}

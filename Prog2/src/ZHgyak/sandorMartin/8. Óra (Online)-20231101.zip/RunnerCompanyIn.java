package j08Expection01Emp;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class RunnerCompanyIn {

	public static void main(String[] args) {
		ArrayList<Company> comanyList = new ArrayList<>();
		File file = new File("company.txt");

		try (Scanner sc = new Scanner(file)) {
			while (sc.hasNextLine()) {
				String l=sc.nextLine();
				System.out.println(l);
				System.out.println();
				String[] sArray=l.split("; ");
				for (String string : sArray) {
					System.out.println(string);
				}
				System.out.println();
				comanyList.add(new Company(sArray[0], sArray[1]));
			}
		} catch (FileNotFoundException e) {
			System.out.println("nincs fájl");
		}
		
		System.out.println("lista");
		for (Company company : comanyList) {
			System.out.println(company);
		}
	}
}

package j08Expection01Emp;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.TreeSet;

public class Department implements Comparable<Department>, Serializable {
	private String id;
	private String name;
	private HashSet<Employee> employees=new HashSet<>();

	public Department(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public HashSet<Employee> getEmployees() {
		return employees;
	}
	
	public void addEmployee(Employee emp) throws DeptNotContainEmpException {
		employees.add(emp);
		emp.setDepartment(this);
	}
	
	public void removeEmployee(Employee emp) throws DeptNotContainEmpException {
		employees.remove(emp);
		emp.setDepartment(null);
	}
	
	public static void employeeMove(Employee emp, Department fromDept, Department toDept) throws DeptNotContainEmpException  {
		fromDept.removeEmployee(emp);
		toDept.addEmployee(emp);
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Department))
			return false;
		Department other = (Department) obj;
		return Objects.equals(id, other.id);
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Department [id=");
		builder.append(id);
		builder.append(", name=");
		builder.append(name);
		builder.append(", employees=");
		builder.append(employees);
		builder.append("]");
		return builder.toString();
	}
	@Override
	public int compareTo(Department o) {
		return this.id.compareTo(o.id);
	}
}

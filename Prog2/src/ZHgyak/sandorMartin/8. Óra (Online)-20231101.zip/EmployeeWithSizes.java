package j08Expection01Emp;

import java.time.LocalDate;

public class EmployeeWithSizes extends Employee{
	private int shoeSize;
	private int heightInCm;
	
	public EmployeeWithSizes(int id, String name, LocalDate birthDate) throws WrongBirthDateExcception {
		super(id, name, birthDate);
	}
	
	public EmployeeWithSizes(int id, String name, LocalDate birthDate, String nickName) throws WrongBirthDateExcception {
		super(id, name, birthDate, nickName);
	}

	public int getShoeSize() {
		return shoeSize;
	}

	public void setShoeSize(int shoeSize) throws ShoeSizeException {
		if (shoeSize>50 || shoeSize<10)
			throw new ShoeSizeException("The shoesize should be between 10 and 50: "+shoeSize);
		this.shoeSize = shoeSize;
	}

	public int getHeightInCm() {
		return heightInCm;
	}

	public void setHeightInCm(int heightInCm) throws HeightException {
		if (heightInCm>300 || heightInCm<20)
			throw new HeightException("The height should be between 20 and 300: "+heightInCm);
		this.heightInCm = heightInCm;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmployeeWithSizes [shoeSize=");
		builder.append(shoeSize);
		builder.append(", heightInCm=");
		builder.append(heightInCm);
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}
	
	
}

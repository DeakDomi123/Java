package j08Expection01Emp;

public class WrongBirthDateExcception extends CompanyException {

	public WrongBirthDateExcception(String message) {
		super(message);
	}

}

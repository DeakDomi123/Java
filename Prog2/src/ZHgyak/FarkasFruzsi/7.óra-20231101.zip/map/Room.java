import java.util.ArrayList;
import java.util.Objects;

public class Room {

    private Building building;
    private String roomId;
    private int numberOfSeats;
    private ArrayList<String> attributes = new ArrayList<>();

    public Room(Building building, String roomId) {
        this.building = building;
        this.roomId = roomId;
    }

    public void setNumberOfSeats(int numberOfSeats) {
        this.numberOfSeats = numberOfSeats;
    }

    public void addAttribute(String attr) {
        attributes.add(attr);
    }

    public void delAttribute(String attr) {
        attributes.remove(attr);
    }

    public Building getBuilding() {
        return building;
    }

    public String getRoomId() {
        return roomId;
    }

    public int getNumberOfSeats() {
        return numberOfSeats;
    }

    public ArrayList<String> getAttributes() {
        return attributes;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Room{");
        sb.append("building=").append(building);
        sb.append(", roomId='").append(roomId).append('\'');
        sb.append(", numberOfSeats=").append(numberOfSeats);
        sb.append(", attributes=").append(attributes);
        sb.append('}');
        return sb.toString();
    }

}

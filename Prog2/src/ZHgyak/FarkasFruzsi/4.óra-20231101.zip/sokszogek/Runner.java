public class Runner2 {
    public static void main(String[] args) {


        Teglalap t1 = new Teglalap(2, 5);
        System.out.println(t1);
        System.out.println(t1.kerulet());
        System.out.println(t1.terulet());

        Negyzet n1 = new Negyzet(3);
        System.out.println(n1);
    }
}
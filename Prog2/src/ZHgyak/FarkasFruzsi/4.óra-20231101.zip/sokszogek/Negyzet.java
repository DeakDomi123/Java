public class Negyzet extends Teglalap {

    public Negyzet(double oldalhossz) {
        super(oldalhossz, oldalhossz);
    }

    public double getOldalhossz() {
        return hosszabbOldal;
//        return getHosszabbOldal();
//        return getRovidebbOldal();
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Negyzet {");
        sb.append("oldalhossz= ").append(getOldalhossz());
        sb.append('}');
        return sb.toString();
    }
}

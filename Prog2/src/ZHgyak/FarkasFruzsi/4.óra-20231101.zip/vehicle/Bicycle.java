public class Bicycle extends Vehicle {

    private int size;

    public Bicycle(String registrationNumber) {
        super(2, registrationNumber);
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Bicaj {");
        sb.append("registrationNumber= ").append(getId());
        sb.append(", size=").append(size);
        sb.append('}');
        return sb.toString();
    }
}

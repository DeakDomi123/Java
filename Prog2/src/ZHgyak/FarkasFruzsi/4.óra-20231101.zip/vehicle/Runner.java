public class Runner {
    public static void main(String[] args) {

//        Vehicle v1 = new Vehicle("id1");
//        v1.setMove();
//        Vehicle v2 = new Vehicle("id2");
//        Vehicle v3 = new Vehicle(2, "id1" );
//        v1.setStatus(VehicleStatus.MOVE);
//
//        System.out.println(v1);
////        System.out.println(v1.toString());
//        System.out.println(v2.getNumberOfWheels());
//
//        System.out.println(v1.equals(v1));
//        System.out.println(v1.equals(v2));
//        System.out.println(v1.equals(v3));
//        System.out.println(v1.equals(new String()));

        Car c1 = new Car("ABC123");
        System.out.println(c1);

        Bicycle b1 = new Bicycle("123456");
        b1.setSize(2);
        System.out.println(b1);

    }
}
public interface Move {

    double getSpeedInMeterPerSec();
}

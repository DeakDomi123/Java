import java.util.Comparator;

public class HorseComparator implements Comparator<Horse> {


    @Override
    public int compare(Horse o1, Horse o2) {
        int szulDat = o1.getBirthDate().compareTo(o2.getBirthDate());
        if (szulDat != 0) {
            return szulDat;
        }
        return o2.getName().compareTo(o1.getName());
    }
}

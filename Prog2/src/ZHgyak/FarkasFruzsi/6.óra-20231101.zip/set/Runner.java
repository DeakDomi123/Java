import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class Runner {
    public static void main(String[] args) {

        System.out.println("hashset");
        HashSet<Building> buildings = new HashSet<>();
        buildings.add(new Building("DEIK", "Kassai 26"));
        buildings.add(new Building("DEIK", "Kassai 27"));
        buildings.add(new Building("DEIK", "Kassai 28"));
        buildings.add(new Building("DEIK", "Kassai 26"));
        buildings.add(new Building("TEOKJ", "Kassai 26"));
        buildings.add(new Building("Foepulet", "Egyetem 1"));

        for (Building building: buildings) {
            System.out.println(building);
        }

        System.out.println("treeset");
        TreeSet<Room> roomTreeSet = new TreeSet<>(new Comparator<Room>() {
            @Override
            public int compare(Room o1, Room o2) {
                int address= o1.getBuilding().getAddress().compareTo(o2.getBuilding().getAddress());
                if (address != 0) {
                    return address;
                }
                return o1.getRoomId().compareTo(o2.getRoomId());
            }
        });
        roomTreeSet.add(new Room(new Building("Foepulet", "Egyetem 1"), "aud max"));
        Room r1 = new Room(new Building("DEIK", "Kassai 26"), "f01");
        r1.addAttribute("eloado");
        r1.setNumberOfSeats(150);
        roomTreeSet.add(r1);
        roomTreeSet.add(new Room(new Building("DEIK", "Kassai 26"), "206"));
        roomTreeSet.add(new Room(new Building("DEIK", "Kassai 26"), "310"));

        for (Room room: roomTreeSet) {
            System.out.println(room);
        }
    }
}